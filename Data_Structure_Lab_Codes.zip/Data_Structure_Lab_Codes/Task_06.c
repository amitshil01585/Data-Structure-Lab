/* Task 6: Find the index of a specific pattern within a string
   (Naive pattern matching algorithm, prints every occurrence) */
#include <stdio.h>
#include <string.h>
 
void findPatternIndices(char text[], char pattern[]) {
    int n = strlen(text);
    int m = strlen(pattern);
    int found = 0;
 
    for (int i = 0; i <= n - m; i++) {
        int j;
        for (j = 0; j < m; j++) {
            if (text[i + j] != pattern[j])
                break;
        }
        if (j == m) {
            printf("Pattern found at index %d\n", i);
            found = 1;
        }
    }
 
    if (!found)
        printf("Pattern not found in the text.\n");
}
 
int main() {
    char text[200], pattern[100];
 
    printf("Enter the text: ");
    scanf("%s", text);
    printf("Enter the pattern: ");
    scanf("%s", pattern);
 
    findPatternIndices(text, pattern);
 
    return 0;
}
